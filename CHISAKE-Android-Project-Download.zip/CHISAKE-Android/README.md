# CHISAKE Android

Android starter with Firebase Email/Password Authentication and Cloud Firestore profile storage.

Package: `com.chisake.app`

Firebase configuration is in `app/google-services.json`. Keep this file paired with the Firebase project that registered this exact Android package.

Build: `gradle assembleDebug` with JDK 17 and Gradle 8.9.

The registration form collects full name, username, email, phone number, date of birth, gender, and password. Email/password handles sign-in; phone number is stored in the Firestore user profile and is not SMS-verified in this version.

Firestore production rules must allow an authenticated user to create/read/update only their own `users/{uid}` document. Configure these rules in Firebase Console before testing profile writes.

## Home Feed (text posts)
This build adds Firestore-backed text posts, feed loading, likes, and comments.

### Required Firestore rules
The project includes `firestore.rules`. In Firebase Console, open **Firestore Database → Rules**, replace the existing rules with the contents of that file, and click **Publish**. Without publishing suitable rules, signed-in users will see permission errors when loading or publishing feed posts.

Posts are stored in `posts/{postId}`. Likes are stored in `posts/{postId}/likes/{userId}` and comments in `posts/{postId}/comments/{commentId}`. User profile information is read from `users/{uid}`.

This stage supports text only. Photo/video uploads, real-time chat, status and friend discovery are not included in this stage.
