# CHISAKE Android

Android starter with Firebase Email/Password Authentication and Cloud Firestore profile storage.

Package: `com.chisake.app`

Firebase configuration is in `app/google-services.json`. Keep this file paired with the Firebase project that registered this exact Android package.

Build: `gradle assembleDebug` with JDK 17 and Gradle 8.9.

The registration form collects full name, username, email, phone number, date of birth, gender, and password. Email/password handles sign-in; phone number is stored in the Firestore user profile and is not SMS-verified in this version.

Firestore production rules must allow an authenticated user to create/read/update only their own `users/{uid}` document. Configure these rules in Firebase Console before testing profile writes.
