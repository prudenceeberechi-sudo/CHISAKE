package com.chisake.app

import android.os.Bundle
import android.util.Patterns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Query
import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar

private val Purple = Color(0xFF6D28D9)
private val DeepPurple = Color(0xFF4C1D95)
private val PalePurple = Color(0xFFF3E8FF)
private val Ink = Color(0xFF211A2B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AuthGate() }
    }
}


@Composable
fun AuthGate() {
    val auth = remember { FirebaseAuth.getInstance() }
    var signedIn by remember { mutableStateOf(auth.currentUser != null) }
    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { signedIn = it.currentUser != null }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }
    if (signedIn) {
        ChisakeApp()
    } else {
        AuthScreen(onSignedIn = { signedIn = true })
    }
}

@Composable
fun AuthScreen(onSignedIn: () -> Unit) {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    var isRegister by remember { mutableStateOf(false) }
    var fullName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var customGender by remember { mutableStateOf("") }
    var day by remember { mutableStateOf("") }
    var month by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var showConfirm by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    val dob = if (day.isNotBlank() && month.isNotBlank() && year.isNotBlank())
        "%02d/%02d/%s".format(day.toInt(), month.toInt(), year) else ""
    val passwordStrong = password.length >= 8 && password.any { it.isUpperCase() } &&
        password.any { it.isLowerCase() } && password.any { it.isDigit() }
    val confirmMatches = confirm.isNotEmpty() && confirm == password

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState()).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Text("CHISAKE", color = Purple, fontSize = 32.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        Text("Connect. Chat. Share. Belong.", color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(28.dp))
        Text(if (isRegister) "Create your account" else "Welcome back", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(if (isRegister) "Join the CHISAKE community" else "Log in to continue", color = Color.Gray)
        Spacer(Modifier.height(18.dp))

        if (isRegister) {
            AuthField("Full name", fullName) { fullName = it }
            AuthField("Username", username) { username = it }
        }
        AuthField("Email address", email, KeyboardType.Email) { email = it }
        if (isRegister) {
            AuthField("Phone number", phone, KeyboardType.Phone) { phone = it }

            Text("Date of birth", modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 5.dp), fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                SelectField("Day", day, (1..31).map { it.toString() }, { day = it }, Modifier.weight(0.8f))
                SelectField("Month", month, listOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"), { month = it }, Modifier.weight(1.5f), displayValue = { value ->
                    value.toIntOrNull()?.let { listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec").getOrNull(it - 1) } ?: value
                }, storedValues = (1..12).map { it.toString() })
                val currentYear = Calendar.getInstance().get(Calendar.YEAR)
                SelectField("Year", year, (1900..currentYear).reversed().map { it.toString() }, { year = it }, Modifier.weight(1.1f))
            }

            SelectField("Gender", gender, listOf("Male", "Female", "Custom"), { gender = it; if (it != "Custom") customGender = "" }, Modifier.fillMaxWidth())
            if (gender == "Custom") {
                AuthField("Enter your gender", customGender) { customGender = it }
            }
        }

        PasswordField(
            label = "Password", value = password, visible = showPassword,
            onValueChange = { password = it }, onToggleVisibility = { showPassword = !showPassword }
        )
        if (isRegister && password.isNotEmpty()) {
            Text(
                if (passwordStrong) "✓ Strong password" else "Use at least 8 characters, including uppercase, lowercase and a number.",
                color = if (passwordStrong) Color(0xFF16803D) else MaterialTheme.colorScheme.error,
                fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(start = 4.dp, bottom = 4.dp)
            )
        }
        if (isRegister) {
            PasswordField(
                label = "Confirm password", value = confirm, visible = showConfirm,
                onValueChange = { confirm = it }, onToggleVisibility = { showConfirm = !showConfirm }
            )
            if (confirm.isNotEmpty()) {
                Text(
                    if (confirmMatches) "✓ Passwords match" else "Passwords do not match",
                    color = if (confirmMatches) Color(0xFF16803D) else MaterialTheme.colorScheme.error,
                    fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(start = 4.dp, bottom = 4.dp)
                )
            }
        }

        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp))
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            if (busy) return@Button
            if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) { message = "Enter a valid email address."; return@Button }
            if (password.length < 6) { message = "Password must contain at least 6 characters."; return@Button }
            if (isRegister && !passwordStrong) { message = "Please choose a stronger password: 8+ characters, uppercase, lowercase and a number."; return@Button }
            if (isRegister && (fullName.isBlank() || username.isBlank() || phone.isBlank() || dob.isBlank() || gender.isBlank() || (gender == "Custom" && customGender.isBlank()))) {
                message = "Please complete all registration fields."; return@Button
            }
            if (isRegister && !confirmMatches) { message = "Your passwords do not match."; return@Button }
            busy = true; message = ""
            if (isRegister) {
                auth.createUserWithEmailAndPassword(email.trim(), password).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val uid = auth.currentUser?.uid
                        val profile = hashMapOf(
                            "uid" to uid, "fullName" to fullName.trim(), "username" to username.trim(),
                            "email" to email.trim(), "phone" to phone.trim(), "dateOfBirth" to dob,
                            "gender" to if (gender == "Custom") customGender.trim() else gender,
                            "createdAt" to System.currentTimeMillis()
                        )
                        if (uid != null) db.collection("users").document(uid).set(profile)
                            .addOnSuccessListener { busy = false; onSignedIn() }
                            .addOnFailureListener { e -> busy = false; message = "Account created, but profile save failed: ${e.localizedMessage}" }
                        else { busy = false; message = "Account created. Please log in." }
                    } else { busy = false; message = task.exception?.localizedMessage ?: "Registration failed." }
                }
            } else {
                auth.signInWithEmailAndPassword(email.trim(), password).addOnCompleteListener { task ->
                    busy = false
                    if (task.isSuccessful) onSignedIn() else message = task.exception?.localizedMessage ?: "Login failed. Check your email and password."
                }
            }
        }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
            Text(if (busy) "Please wait..." else if (isRegister) "CREATE ACCOUNT" else "LOG IN")
        }
        TextButton(onClick = { isRegister = !isRegister; message = "" }) {
            Text(if (isRegister) "Already have an account? Log in" else "New to CHISAKE? Create account", color = Purple)
        }
        Spacer(Modifier.height(20.dp))
    }
}

private fun itIndex(monthName: String): Int = listOf(
    "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"
).indexOf(monthName)

@Composable
fun SelectField(
    label: String,
    value: String,
    options: List<String>,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    displayValue: (String) -> String = { it },
    storedValues: List<String> = options
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier.padding(vertical = 5.dp)) {
        OutlinedTextField(
            value = if (value.isBlank()) "" else displayValue(value),
            onValueChange = {}, readOnly = true, label = { Text(label) },
            trailingIcon = { Icon(Icons.Filled.ArrowDropDown, contentDescription = "Choose $label") },
            modifier = Modifier.fillMaxWidth().clickable { expanded = true },
            singleLine = true
        )
        Box(Modifier.matchParentSize().clickable { expanded = true })
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, modifier = Modifier.heightIn(max = 280.dp)) {
            options.forEachIndexed { index, option ->
                DropdownMenuItem(text = { Text(option) }, onClick = {
                    onSelect(storedValues.getOrElse(index) { option }); expanded = false
                })
            }
        }
    }
}

@Composable
fun PasswordField(
    label: String,
    value: String,
    visible: Boolean,
    onValueChange: (String) -> Unit,
    onToggleVisibility: () -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        singleLine = true,
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = {
            IconButton(onClick = onToggleVisibility) {
                Icon(if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = if (visible) "Hide password" else "Show password")
            }
        }
    )
}

@Composable
fun AuthField(label: String, value: String, type: KeyboardType = KeyboardType.Text, onValueChange: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = onValueChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = type))
}

@Composable
fun ChisakeApp() {
    var selected by remember { mutableStateOf("Home") }
    var dark by remember { mutableStateOf(false) }
    val scheme = if (dark) darkColorScheme(primary = Color(0xFFC4A7FF), secondary = Purple)
                 else lightColorScheme(primary = Purple, secondary = DeepPurple, background = Color(0xFFFAF8FC))
    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = { TopBar() },
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    val tabs = listOf(
                        "Home" to Icons.Filled.Home,
                        "Friends" to Icons.Filled.People,
                        "Chats" to Icons.Filled.Chat,
                        "Status" to Icons.Filled.Circle,
                        "Profile" to Icons.Filled.Person
                    )
                    tabs.forEach { (label, icon) ->
                        NavigationBarItem(
                            selected = selected == label,
                            onClick = { selected = label },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) }
                        )
                    }
                }
            },
            floatingActionButton = {
                if (selected == "Home") FloatingActionButton(
                    onClick = { selected = "Create post" },
                    containerColor = Purple,
                    contentColor = Color.White
                ) { Icon(Icons.Filled.Add, contentDescription = "Create post") }
            }
        ) { padding ->
            Box(Modifier.padding(padding)) {
                when (selected) {
                    "Home" -> HomeScreen()
                    "Friends" -> FriendsScreen()
                    "Chats" -> ChatsScreen()
                    "Status" -> StatusScreen()
                    "Profile" -> ProfileScreen()
                    "Create post" -> CreatePostScreen(onBack = { selected = "Home" })
                    "Settings" -> SettingsScreen(dark, { dark = it })
                    else -> HomeScreen()
                }
            }
        }
    }
}

@Composable
fun TopBar() {
    Row(
        Modifier.fillMaxWidth().background(Purple).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("CHISAKE", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
            Text("Connect. Chat. Share. Belong.", color = Color.White.copy(alpha = .85f), fontSize = 11.sp)
        }
        Row {
            IconButton(onClick = {}) { Icon(Icons.Filled.Search, "Search", tint = Color.White) }
            IconButton(onClick = {}) { Icon(Icons.Filled.Notifications, "Notifications", tint = Color.White) }
        }
    }
}

@Composable
fun ScreenTitle(title: String, subtitle: String? = null) {
    Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        if (subtitle != null) Text(subtitle, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .6f), fontSize = 13.sp)
    }
}

data class FeedPost(val id: String, val uid: String, val name: String, val username: String, val time: String, val body: String, val likes: Int, val comments: Int, val liked: Boolean = false)

@Composable
fun HomeScreen() {
    val db = remember { FirebaseFirestore.getInstance() }
    val uid = FirebaseAuth.getInstance().currentUser?.uid
    var posts by remember { mutableStateOf<List<FeedPost>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    DisposableEffect(uid) {
        val registration: ListenerRegistration? = db.collection("posts")
            .orderBy("createdAt", Query.Direction.DESCENDING).limit(60)
            .addSnapshotListener { snapshot, exception ->
                if (exception != null) { error = exception.localizedMessage ?: "Unable to load posts."; loading = false }
                else {
                    val docs = snapshot?.documents.orEmpty()
                    posts = docs.map { d ->
                        val stamp = d.getTimestamp("createdAt")
                        val time = stamp?.toDate()?.let { SimpleDateFormat("dd MMM, h:mm a", Locale.getDefault()).format(it) } ?: "Just now"
                        FeedPost(d.id, d.getString("uid") ?: "", d.getString("authorName") ?: "CHISAKE user", d.getString("authorUsername") ?: "", time, d.getString("text") ?: "", (d.getLong("likeCount") ?: 0L).toInt(), (d.getLong("commentCount") ?: 0L).toInt())
                    }
                    loading = false; error = ""
                    if (uid != null) posts.forEach { post ->
                        db.collection("posts").document(post.id).collection("likes").document(uid).get()
                            .addOnSuccessListener { likedDoc -> posts = posts.map { if (it.id == post.id) it.copy(liked = likedDoc.exists()) else it } }
                    }
                }
            }
        onDispose { registration?.remove() }
    }
    LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) {
        item { ScreenTitle("Your feed", "See what's happening with your people.") }
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar("Y", 46); Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) { Text("What's on your mind?", fontWeight = FontWeight.Medium); Text("Share a moment with friends", fontSize = 12.sp, color = Color.Gray) }
                    Icon(Icons.Filled.AddCircle, null, tint = Purple, modifier = Modifier.size(30.dp))
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)); Text("  STORIES", fontWeight = FontWeight.Bold, color = Purple, fontSize = 12.sp) }
        item { Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf("You", "Friends").forEachIndexed { i, name -> Column(horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.background(if (i == 0) PalePurple else Purple, CircleShape).padding(3.dp)) { Avatar(name.take(1), 48, if (i == 0) Purple else Color.White) }; Text(name, fontSize = 11.sp) } }
        } }
        if (loading) item { Box(Modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Purple) } }
        if (error.isNotBlank()) item { Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(18.dp)) }
        if (!loading && posts.isEmpty() && error.isBlank()) item { Text("No posts yet. Be the first to share something!", modifier = Modifier.padding(22.dp), color = Color.Gray) }
        items(posts, key = { it.id }) { post -> PostCard(post) }
    }
}

@Composable
fun PostCard(post: FeedPost) {
    val db = remember { FirebaseFirestore.getInstance() }
    val uid = FirebaseAuth.getInstance().currentUser?.uid
    var liked by remember(post.id) { mutableStateOf(post.liked) }
    var likeCount by remember(post.id) { mutableIntStateOf(post.likes) }
    var commentOpen by remember { mutableStateOf(false) }
    var commentText by remember { mutableStateOf("") }
    var commentMessage by remember { mutableStateOf("") }
    var comments by remember(post.id) { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    LaunchedEffect(post.liked, post.likes) { liked = post.liked; likeCount = post.likes }
    DisposableEffect(post.id, commentOpen) {
        val listener = if (commentOpen) db.collection("posts").document(post.id).collection("comments")
            .orderBy("createdAt", Query.Direction.ASCENDING).limit(100)
            .addSnapshotListener { snap, _ -> comments = snap?.documents.orEmpty().map { (it.getString("authorName") ?: "User") to (it.getString("text") ?: "") } } else null
        onDispose { listener?.remove() }
    }
    if (commentOpen) {
        AlertDialog(onDismissRequest = { commentOpen = false }, title = { Text("Comments") },
            text = { Column(Modifier.heightIn(max = 360.dp)) {
                LazyColumn(Modifier.weight(1f, fill = false)) { items(comments) { c -> Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Text(c.first, fontWeight = FontWeight.Bold); Text(c.second) } } }
                OutlinedTextField(value = commentText, onValueChange = { commentText = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Write a comment...") })
                if (commentMessage.isNotBlank()) Text(commentMessage, color = MaterialTheme.colorScheme.error)
            } }, confirmButton = { TextButton(onClick = {
                if (uid == null) { commentMessage = "Please log in again."; return@TextButton }
                if (commentText.isBlank()) { commentMessage = "Write a comment first."; return@TextButton }
                db.collection("users").document(uid).get().addOnSuccessListener { user ->
                    val data = hashMapOf("uid" to uid, "authorName" to (user.getString("fullName") ?: "CHISAKE user"), "text" to commentText.trim(), "createdAt" to FieldValue.serverTimestamp())
                    db.collection("posts").document(post.id).collection("comments").add(data).addOnSuccessListener { db.collection("posts").document(post.id).update("commentCount", FieldValue.increment(1)); commentText = ""; commentOpen = false }
                        .addOnFailureListener { commentMessage = it.localizedMessage ?: "Comment failed." }
                }.addOnFailureListener { commentMessage = it.localizedMessage ?: "Could not load your profile." }
            }) { Text("Send") } }, dismissButton = { TextButton(onClick = { commentOpen = false }) { Text("Close") } })
    }
    Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Avatar(post.name.take(1), 42); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(post.name, fontWeight = FontWeight.Bold); Text(if (post.username.isBlank()) post.time else "@${post.username} · ${post.time}", color = Color.Gray, fontSize = 11.sp) }; Icon(Icons.Filled.MoreHoriz, null, tint = Color.Gray) }
            Spacer(Modifier.height(13.dp)); Text(post.body, lineHeight = 22.sp); Spacer(Modifier.height(14.dp)); HorizontalDivider(color = PalePurple)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                TextButton(onClick = {
                    if (uid == null) return@TextButton
                    val likeRef = db.collection("posts").document(post.id).collection("likes").document(uid)
                    if (liked) likeRef.delete().addOnSuccessListener { liked = false; likeCount = (likeCount - 1).coerceAtLeast(0); db.collection("posts").document(post.id).update("likeCount", FieldValue.increment(-1)) }
                    else likeRef.set(mapOf("uid" to uid, "createdAt" to FieldValue.serverTimestamp())).addOnSuccessListener { liked = true; likeCount++; db.collection("posts").document(post.id).update("likeCount", FieldValue.increment(1)) }
                }) { Icon(if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = Purple); Spacer(Modifier.width(5.dp)); Text(if (liked) "Liked" else "Like") }
                TextButton(onClick = { commentOpen = true }) { Icon(Icons.Filled.ModeComment, null, tint = Purple); Spacer(Modifier.width(5.dp)); Text("${post.comments} Comments") }
                TextButton(onClick = {}) { Icon(Icons.Filled.Share, null, tint = Purple); Spacer(Modifier.width(5.dp)); Text("Share") }
            }
            Text("$likeCount likes", color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
fun Avatar(letter: String, size: Int, color: Color = Color.White) {
    Box(Modifier.size(size.dp).background(Purple, CircleShape), contentAlignment = Alignment.Center) {
        Text(letter, color = color, fontWeight = FontWeight.Bold, fontSize = (size / 2.4).sp)
    }
}

@Composable
fun FriendsScreen() {
    ScreenTitle("Friends", "Find and connect with people.")
    Column(Modifier.padding(16.dp)) {
        OutlinedTextField(value = "", onValueChange = {}, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search by name or phone number") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, shape = RoundedCornerShape(14.dp))
        Spacer(Modifier.height(18.dp))
        listOf("Ada Nwosu", "Daniel King", "Mimi James", "Tobi A.").forEach {
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(it.take(1), 44); Spacer(Modifier.width(12.dp))
                Text(it, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Add") }
            }
        }
    }
}

@Composable
fun ChatsScreen() {
    ScreenTitle("Messages", "Your private and group conversations.")
    Column(Modifier.padding(horizontal = 16.dp)) {
        OutlinedTextField(value = "", onValueChange = {}, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search messages") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, shape = RoundedCornerShape(14.dp))
        Spacer(Modifier.height(12.dp))
        listOf("Ada Nwosu" to "Are we still meeting today?", "Graphic Design Class" to "You: The new lesson is ready.", "Daniel King" to "Sent a voice note", "Mimi James" to "Thank you so much 💜").forEach { (name, msg) ->
            Row(Modifier.fillMaxWidth().clickable { }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(name.take(1), 48); Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Text(name, fontWeight = FontWeight.Bold); Text(msg, color = Color.Gray, fontSize = 13.sp) }
                Icon(Icons.Filled.ChevronRight, null, tint = Purple)
            }
            HorizontalDivider(color = PalePurple)
        }
    }
}

@Composable
fun StatusScreen() {
    ScreenTitle("Status", "Share a photo, video or thought.")
    Column(Modifier.padding(16.dp)) {
        Card(shape = RoundedCornerShape(16.dp)) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar("+", 48); Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Text("My status", fontWeight = FontWeight.Bold); Text("Tap to add an update", color = Color.Gray, fontSize = 12.sp) }
                Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Add") }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("RECENT UPDATES", color = Purple, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        listOf("Ada Nwosu", "Daniel King", "Mimi James").forEach {
            Row(Modifier.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.background(PalePurple, CircleShape).padding(3.dp)) { Avatar(it.take(1), 46) }
                Spacer(Modifier.width(12.dp)); Column { Text(it, fontWeight = FontWeight.SemiBold); Text("Today · Tap to view", color = Color.Gray, fontSize = 12.sp) }
            }
        }
    }
}

@Composable
fun ProfileScreen() {
    val db = remember { FirebaseFirestore.getInstance() }
    val user = FirebaseAuth.getInstance().currentUser
    var fullName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var hobbies by remember { mutableStateOf("") }
    var likes by remember { mutableStateOf("") }
    var dislikes by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var editing by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    LaunchedEffect(user?.uid) {
        val uid = user?.uid
        if (uid != null) db.collection("users").document(uid).get()
            .addOnSuccessListener { doc ->
                fullName = doc.getString("fullName") ?: ""
                username = doc.getString("username") ?: ""
                bio = doc.getString("bio") ?: ""
                hobbies = doc.getString("hobbies") ?: ""
                likes = doc.getString("likes") ?: ""
                dislikes = doc.getString("dislikes") ?: ""
                loading = false
            }
            .addOnFailureListener { message = it.localizedMessage ?: "Could not load profile."; loading = false }
        else loading = false
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        ScreenTitle("My profile", "Your CHISAKE identity.")
        Box(Modifier.fillMaxWidth().height(116.dp).background(PalePurple, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            Text("Cover photo · Coming soon", color = DeepPurple, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(fullName.firstOrNull()?.uppercase() ?: "C", 72)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(fullName.ifBlank { "CHISAKE user" }, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text(if (username.isBlank()) "@username" else "@$username", color = Purple)
                Text(user?.email ?: "", color = Color.Gray, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        if (loading) {
            LinearProgressIndicator(Modifier.fillMaxWidth(), color = Purple)
        } else if (editing) {
            Text("EDIT YOUR PROFILE", color = Purple, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            AuthField("Full name", fullName) { fullName = it }
            AuthField("Username", username) { username = it }
            OutlinedTextField(value = bio, onValueChange = { bio = it }, label = { Text("Bio") }, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), minLines = 2)
            AuthField("Hobbies", hobbies) { hobbies = it }
            AuthField("Likes", likes) { likes = it }
            AuthField("Dislikes", dislikes) { dislikes = it }
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            Button(onClick = {
                val uid = user?.uid
                if (uid == null) { message = "Please log in again."; return@Button }
                if (fullName.isBlank() || username.isBlank()) { message = "Full name and username are required."; return@Button }
                saving = true; message = ""
                val updates = mapOf("fullName" to fullName.trim(), "username" to username.trim().removePrefix("@"), "bio" to bio.trim(), "hobbies" to hobbies.trim(), "likes" to likes.trim(), "dislikes" to dislikes.trim())
                db.collection("users").document(uid).update(updates)
                    .addOnSuccessListener { saving = false; editing = false; message = "Profile updated successfully." }
                    .addOnFailureListener { saving = false; message = it.localizedMessage ?: "Could not save profile." }
            }, enabled = !saving, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                Text(if (saving) "Saving..." else "Save profile")
            }
            OutlinedButton(onClick = { editing = false; message = "" }, modifier = Modifier.fillMaxWidth()) { Text("Cancel", color = Purple) }
        } else {
            Text(bio.ifBlank { "Add a short bio to tell people about yourself." }, color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
            ProfileDetail("Hobbies", hobbies)
            ProfileDetail("Likes", likes)
            ProfileDetail("Dislikes", dislikes)
            if (message.isNotBlank()) Text(message, color = Color(0xFF16803D), fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
            Button(onClick = { editing = true; message = "" }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Icon(Icons.Filled.Edit, null); Spacer(Modifier.width(8.dp)); Text("Edit profile") }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { FirebaseAuth.getInstance().signOut() }, modifier = Modifier.fillMaxWidth()) { Text("Log out", color = Purple) }
    }
}

@Composable
fun ProfileDetail(label: String, value: String) {
    if (value.isNotBlank()) {
        Column(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
            Text(label, color = Purple, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(value, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun Stat(number: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(number, fontWeight = FontWeight.Bold, fontSize = 19.sp); Text(label, color = Color.Gray, fontSize = 12.sp) }
}

@Composable
fun CreatePostScreen(onBack: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    val auth = remember { FirebaseAuth.getInstance() }
    var text by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, null) }; Text("Create post", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(value = text, onValueChange = { text = it; message = "" }, modifier = Modifier.fillMaxWidth().height(190.dp), placeholder = { Text("What's on your mind?") }, supportingText = { Text("${text.length}/2000") })
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.weight(1f))
        Button(onClick = {
            val user = auth.currentUser
            if (user == null) { message = "Please log in again to publish."; return@Button }
            if (text.isBlank()) { message = "Write something before publishing."; return@Button }
            if (text.length > 2000) { message = "Your post is too long. Keep it under 2,000 characters."; return@Button }
            busy = true; message = ""
            db.collection("users").document(user.uid).get().addOnSuccessListener { profile ->
                val post = hashMapOf("uid" to user.uid, "authorName" to (profile.getString("fullName") ?: user.email ?: "CHISAKE user"), "authorUsername" to (profile.getString("username") ?: ""), "text" to text.trim(), "createdAt" to FieldValue.serverTimestamp(), "likeCount" to 0L, "commentCount" to 0L)
                db.collection("posts").add(post).addOnSuccessListener { busy = false; onBack() }.addOnFailureListener { busy = false; message = it.localizedMessage ?: "Post could not be published." }
            }.addOnFailureListener { busy = false; message = it.localizedMessage ?: "Could not load your profile." }
        }, enabled = !busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text(if (busy) "Publishing..." else "Publish post") }
    }
}

@Composable
fun SettingsScreen(dark: Boolean, onDarkChange: (Boolean) -> Unit) {
    ScreenTitle("Settings", "Make CHISAKE yours.")
    Column(Modifier.padding(horizontal = 18.dp)) {
        SettingRow("Account", "Name, phone number and password", Icons.Filled.ManageAccounts)
        SettingRow("Privacy", "Profile visibility and blocked users", Icons.Filled.Lock)
        SettingRow("Notifications", "Sounds and alerts", Icons.Filled.Notifications)
        SettingRow("Chats", "Chat themes and archived chats", Icons.Filled.Chat)
        SettingRow("Saved posts", "Your bookmarked posts", Icons.Filled.Bookmark)
        SettingRow("Recently watched", "Reels and status history", Icons.Filled.History)
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.DarkMode, null, tint = Purple); Spacer(Modifier.width(12.dp))
            Text("Dark mode", Modifier.weight(1f)); Switch(checked = dark, onCheckedChange = onDarkChange)
        }
    }
}

@Composable
fun SettingRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(Modifier.fillMaxWidth().clickable { }.padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Purple); Spacer(Modifier.width(14.dp))
        Column { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Color.Gray, fontSize = 12.sp) }
    }
}
