# CHISAKE Android starter

Purple-and-white Android app starter built with Kotlin and Jetpack Compose.

## Build an APK with GitHub Actions
1. Upload the contents of this folder to the root of your `chisake` GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build CHISAKE Android APK**.
4. Tap **Run workflow** (or wait for the automatic build after pushing).
5. When the run succeeds, open it and download the `CHISAKE-Android-debug` artifact.
6. Extract the ZIP artifact and install `app-debug.apk` on your Android phone.

## Important
This is the first installable UI foundation. It includes navigation and sample screens for the feed, friends, chats, status, profile and settings. The sample names/posts are demo content. Registration, cloud database, real friend discovery, live messaging, voice notes, voice/video calling, media upload, notifications and production security still need backend integration and testing. Do not use this starter to store real private conversations or passwords yet.

Package name: `com.chisake.app`
