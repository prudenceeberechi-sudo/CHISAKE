# CHISAKE Android

Firebase-connected starter with email/password registration and login. Registration collects name, username, email, phone, date of birth and gender. User profile fields are saved in Cloud Firestore.

Package: `com.chisake.app`

Before testing: in Firebase Console enable Authentication > Sign-in method > Email/Password, and create a Cloud Firestore database. Apply secure Firestore rules before public launch.
